# Crown Market Monitor v1 — MVP

Pages:
- Crown Now
- Cross-Asset
- State Explorer

Run:
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

Current mode: demo data. Next step is replacing demo loaders with the Crown dashboard bundle.
