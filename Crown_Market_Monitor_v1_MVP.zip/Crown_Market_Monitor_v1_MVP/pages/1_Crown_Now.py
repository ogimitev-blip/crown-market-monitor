import streamlit as st
from crown_monitor.data import load_market,load_active_states
from crown_monitor.ui import state_card
m=load_market(); s=load_active_states()
st.title("♛ Crown Now")
st.caption("Decision cockpit — demo data until live Crown bundle is connected")
a,b,c=st.columns(3)
a.metric("Overall Risk",m["overall_risk"]); b.metric("Market",m["market"]); c.metric("Portfolio Action",m["portfolio_action"])
a,b,c=st.columns(3)
a.metric("Macro",m["macro"]); b.metric("Rates",m["rates"]); c.metric("Event Risk",m["event_risk"])
st.subheader("Market strip")
for i in range(0,len(m["metrics"]),3):
    cols=st.columns(3)
    for j,x in enumerate(m["metrics"][i:i+3]): cols[j].metric(x["name"],x["value"],x["delta"])
st.subheader("What changed")
for x in m["changes"]: st.write("•",x)
st.subheader("Active Crown states")
for _,r in s.iterrows(): state_card(r)
