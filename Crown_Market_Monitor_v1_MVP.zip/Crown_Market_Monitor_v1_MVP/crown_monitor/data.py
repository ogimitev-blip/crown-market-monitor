from pathlib import Path
import json
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
def load_market(): return json.loads((DATA/"demo_market.json").read_text(encoding="utf-8"))
def load_active_states(): return pd.DataFrame(json.loads((DATA/"demo_active_states.json").read_text(encoding="utf-8")))
def load_state_dictionary(): return pd.read_csv(DATA/"state_dictionary.csv")
def load_cross_asset(): return pd.read_csv(DATA/"demo_cross_asset.csv")
